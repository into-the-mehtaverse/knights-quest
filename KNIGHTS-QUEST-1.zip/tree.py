class Node:
    def __init__(self, value=0):
        self._value = value
        self._parent = None
        self._children = []

    @property
    def value (self):
        return self._value

    @property
    def children (self):
        return self._children

    @property
    def parent (self):
        return self._parent

    def add_child (self, child_node):
        self.children.append(child_node)
        if (child_node.parent != self):
            child_node.parent = self
        return self.children

    def remove_child (self, child_node):
      if (child_node in self.children):
        self.children.remove(child_node)
        child_node.parent = None
        return self.children

    @parent.setter
    def parent (self, parent_node):
        if (self._parent == parent_node):
            return

        if (self.parent is not None):
            self.parent.remove_child(self)

        self._parent = parent_node
        if parent_node is not None and self not in parent_node.children:
            parent_node.add_child(self)

    def depth_search (self, value):

        if self.value == value:
            return self

        for child in self.children:
            result = child.depth_search(value)
            if result:
                return result

        return None

    def breadth_search (self, value):

        current = self
        queue = []
        queue.append(current)

        while len(queue) > 0:

            current = queue.pop()

            if current.value == value:
                return current

            for child in current.children:
                queue.append(child)

        return None
