from tree import Node

class KnightPathFinder:
    def __init__ (self, root = (0,0)):
        self._root = Node(root)
        self._considered_positions = set(root)

    def get_valid_moves(self, pos):
        result = set()

        downRightOne = (pos[0]+2, pos[1]+1)
        downLeftOne = (pos[0]+2, pos[1]-1)
        upRightOne = (pos[0]-2, pos[1]+1)
        upLeftOne = (pos[0]-2, pos[1]-1)
        downRightTwo = (pos[0]+1, pos[1]+2)
        downLeftTwo = (pos[0]+1, pos[1]-2)
        upRightTwo = (pos[0]-1, pos[1]+2)
        upLeftTwo = (pos[0]-1, pos[1]+2)

        moves = [downRightOne, downLeftOne, upLeftOne, upRightOne, downRightTwo, downLeftTwo, upRightTwo, upLeftTwo]

        for move in moves:
            if (move[0] >= 0 and move[1] >= 0) and (move[0] <= 7 and move[1] <= 7):
                result.add(move)

        return result


    def new_move_positions(self, pos):
        valid_moves = self.get_valid_moves(pos)
        result = set()
        for move in valid_moves:
            if move not in self._considered_positions:
                result.add(move)
                self._considered_positions.add(move)

        return result

    def build_move_tree (self):
        current = self._root
        queue = []
        queue.append(current)

        while len(queue) > 0:
            queueNode = queue.pop(0)
            moves = self.new_move_positions(queueNode.value)

            for move in moves:
                move_node = Node(move)
                queueNode.add_child(move_node)
                queue.append(move_node)

        return self._root

    def find_path(self, end_position):
        end_node = self._root.depth_search(end_position)
        if not end_node:
            return []
        return self.trace_to_root(end_node)

    def trace_to_root(self, end_node):
        current = end_node
        trace_path = []
        while current:
            trace_path.append(current.value)
            current = current.parent
        trace_path.reverse()
        return trace_path

finder = KnightPathFinder((0, 0))
finder.build_move_tree()
print(finder.find_path((2, 1))) # => [(0, 0), (2, 1)]
print(finder.find_path((3, 3))) # => [(0, 0), (2, 1), (3, 3)]
print(finder.find_path((6, 2))) # => [(0, 0), (1, 2), (2, 4), (4, 3), (6, 2)]
print(finder.find_path((7, 6))) # => [(0, 0), (1, 2), (2, 4), (4, 3), (5, 5), (7, 6)]
