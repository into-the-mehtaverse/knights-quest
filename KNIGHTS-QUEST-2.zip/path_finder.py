from tree import Node

class KnightPathFinder:
    def __init__ (self, root = (0, 0)):
        self._root = root
        self._considered_positions = set(root)

    def get_valid_moves(self, pos):
        result = set()

        downRightOne = (pos[0]+2, pos[1]+1)
        downLeftOne = (pos[0]+2, pos[1]-1)
        upRightOne = (pos[0]-2, pos[1]+1)
        upLeftOne = (pos[0]-2, pos[1]-1)
        downRightTwo = (pos[0]+1, pos[1]+2)
        downLeftTwo = (pos[0]+1, pos[1]-2)
        upRightTwo = (pos[0]-1, pos[1]+2)
        upLeftTwo = (pos[0]-1, pos[1]+2)

        moves = [downRightOne, downLeftOne, upLeftOne, upRightOne, downRightTwo, downLeftTwo, upRightTwo, upLeftTwo]

        for move in moves:
            if (move[0] >= 0 and move[1] >= 0) and (move[0] <= 7 and move[1] <= 7):
                result.add(move)

        return result


    def new_move_positions(self, pos):
        valid_moves = self.get_valid_moves(pos)
        result = set()
        for move in valid_moves:
            if move not in self._considered_positions:
                result.add(move)
                self._considered_positions.add(move)

        return result
